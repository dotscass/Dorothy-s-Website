function Hotel(names, rooms, booked){
this.name = names;
this.rooms = rooms;
this.booked = booked;
this.checkAvailability = function(){
	return this.rooms - this.booked;
};
}


var quayHotel = new Hotel('Quay', 40, 25);

var elname1 = document.getElementById('hotel1'); //get
elname1.textContent = quayHotel.name + " rooms: " + quayHotel.checkAvailability();//update HTML with property of the object


var parkHotel = new Hotel('Park', 120, 77);

var elname2 = document.getElementById('hotel2'); //get
elname2.textContent = parkHotel.name + " rooms: " + parkHotel.checkAvailability();//update HTML with property of the object