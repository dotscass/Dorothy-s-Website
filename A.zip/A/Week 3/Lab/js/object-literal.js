//set up the object
var hotel = {
	name: 'Quay',
	rooms: 40,
	booked: 25,
	gym: true,
	roomTypes: ['twin', 'double', 'suite'],
	checkAvailability: function () {
		return this.rooms - this.booked;

	}
};
//update the HTML

var elname = document.getElementById('hotelName'); //get
elname.textContent = hotel.name;//update HTML with property of the object

var elRooms.textContent=document.getElementById('rooms'); //get element
elRooms.textContent=hottel.checkAvailability(); //update HTML with property of the object

/*
NOTE: textContent does not work in IE8 or earlier
you can use innerHTML on lines 13 and 16
*/