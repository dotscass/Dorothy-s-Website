<?php
	echo 'Shop here';
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Country Crafts</title>
<link href="eCommerceAssets/styles/eCommerceStyle.css" rel="stylesheet" type="text/css">


<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.-->
<script>var __adobewebfontsappname__="dreamweaver";</script>
<script src="http://use.edgefonts.net/montserrat:n4:default;source-sans-pro:n2:default.js" type="text/javascript">
	
</script>
</head>

<body>
<div id="mainWrapper">
  <header> 
    <!-- This is the header content. It contains Logo and links -->
    
    <div id="headerLinks"><a href=login/login.php title="Login/Register">Login/Register</a><a href="cart/local_storage.html" title="Cart">Cart</a>
  </header>
  
  <section id="offer"> 
  <div id="logo"><img src="images/goat.jpg" width="170" height="160" alt="sample logo"></div>
  
    <!-- The offer section displays a banner text for promotions -->
    <h2>Country Crafts</h2>
    <p>Authentic Irish Handmade Food and Crafts</p>
  </section>
  <div id="content">
    <section class="sidebar"> 
      
      <div id="menubar">
        <nav class="menu">
          <h2><!-- Title for menuset 1 -->Crafts </h2>
          <hr>
          <ul>
            <!-- List of links under menuset 1 -->
            <li><a href="soap.html" title="Link">Soap</a></li>
            <li><a href="candles.html" title="Link">Candles</a></li>
            <li><a href="lipBalm.html" title="Link">Lip Balm</a></li>
          
          </ul>
        </nav>
        <nav class="menu">
          <h2>Natural Foods </h2>
          <!-- Title for menuset 2 -->
          <hr>
          <ul>
            <!--List of links under menuset 2 -->
            <li><a href="goatsmilk.html" title="Link">Goats Milk</a></li>
            <li><a href="honey.html" title="Link">Honey</a></li>
            <li><a href="butter.html" title="Link">Butter</a></li>
            
          </ul>
        </nav>
      </div>
    </section>
    <section class="mainContent">
      <div class="productRow"><!-- Each product row contains info of 3 elements -->
        <article class="productInfo"><!-- Each individual product description -->
          <div><img alt="sample" src="images/soap.jfif" width="323" height="165" /></div>
          <p class="price"></p>
          <p class="productContent"></p>
          <button> <a href="soap.html">Buy</button>
        </article>
        <article class="productInfo"><!-- Each individual product description -->
          <div><img alt="sample" src="images/candles.jfif"></div>
          <p class="price"></p>
          <p class="productContent"></p>
          <button> <a href="candles.html">Buy</button>
        </article>
        <article class="productInfo"> <!-- Each individual product description -->
          <div><img alt="sample" src="images/lipbalm.jfif"  width="259" height="165"></div>
          <p class="price"></p>
          
          <button> <a href="lipBalm.html">Buy</button>
        </article>
      </div>
      <div class="productRow"> 
        <!-- Each product row contains info of 3 elements -->
        <article class="productInfo"> <!-- Each individual product description -->
          <div><img alt="sample" src="images/goatsmilk.jfif"  width="259" height="165"></div>
          <p class="price"></p>
          
          <button> <a href="goatsmilk.html">Buy</button>
        </article>
        <article class="productInfo"> <!-- Each individual product description -->
          <div><img alt="sample" src="images/honey.jfif"  width="275" height="183"></div>
          
          <button> <a href="honey.html">Buy</button>
        </article>
        <article class="productInfo"><!-- Each individual product description -->
          <div><img alt="sample" src="images/butter.jpg"  width="259" height="165"></div>
          
          <button> <a href="butter.html">Buy</button>
        </article>
      </div>
      
    </section>
  
</body>
</html>

