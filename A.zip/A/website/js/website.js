
var soap=document.getElementsByClassName("soap");
for(var i=0; i<soap.length; i++){
	soap[i].addEventListener("click", addtoCart, true);
	console.log(soap[i]);
}
var soapObj={lavQuantity:0, oatQuantity: 0, honeyQuantity:0, appleQuantity:0, honeyCQuantity:0, roseQuantity:0, vanillaQuantity:0,
orangeQuantity:0, berryQuantity:0 };


function addtoCart(){
	alert("Item added to Cart");
	if (this.getAttribute("id")==="lav") {
		soapObj.lavQuantity++;
		console.log(soapObj);

	}
	else if(this.getAttribute("id")==="oat"){
		soapObj.oatQuantity++;
		console.log(soapObj);

	}
	else if(this.getAttribute("id")==="honey"){
		soapObj.honeyQuantity++;
		console.log(soapObj);

	}
	else if(this.getAttribute("id")==="apple") {
			soapObj.appleQuantity++;
			console.log(soapObj);

		}
	else if(this.getAttribute("id")==="honeyC"){
			soapObj.honeyCQuantity++;
			console.log(soapObj);

		}
	else if (this.getAttribute("id")==="rose"){
			soapObj.roseQuantity++;
			console.log(soapObj);

		}
	else if(this.getAttribute("id")==="berry") {
			soapObj.berryQuantity++;
			console.log(soapObj);

		}
	else if(this.getAttribute("id")==="orange"){
			soapObj.orangeQuantity++;
			console.log(soapObj);

		}
	else if (this.getAttribute("id")==="vanilla"){
			soapObj.vanillaQuantity++;
			console.log(soapObj);

		}
	localStorage.setItem("soap", JSON.stringify(soapObj));
	
}
var newObj=JSON.parse(localStorage.getItem("soap"));
console.log(newObj);

var checkout1=document.getElementsByClassName("check");
console.log(checkout1);
if (checkout1===null){
	console.log("checkout1 is null");
}else{
	//for(var i=0; i<checkout1.length; i++){
	console.log(document.getElementById('dorothy'));
	document.getElementById('dorothy').addEventListener("load", checkoutfun(), true);
//}
}

function checkoutfun() {
	var test=document.getElementById("test");
	//console.log(test);
	var content="<table border='1px solid black' id='t1'><tr><td>Name</td><td>Price</td><td>Quantity</td><td>Total</td></tr>";
	test.innerHTML=content;
	if(newObj.lavQuantity>0){
		newObj.lavQuantity++;
		lavName="Lavender Soap";
		lavPrice=5.50;
		content+= '<tr><td>';
		content+=lavName;
		content+="</td><td>";
		content+=lavPrice;
		content+="</td><td>";
		content+=newObj.lavQuantity;
		content+="</td><td>";
		content+=lavPrice;
		content+="</td></tr>";
		
	}
	 if(newObj.oatQuantity>0){
	 	
		oatName="Oatmeal Soap";
		oatPrice=6.50;
		content+= '<tr><td>';
		content+=oatName;
		content+="</td><td>";
		content+=oatPrice;
		content+="</td><td>";
		content+=newObj.oatQuantity;
		content+="</td><td>";
		content+=oatPrice;
		content+="</td></tr>";
		
	}
	content+='</table>';
	test.innerHTML=content;
	}

function getTarget(e) {                          // Declare function
  if (!e) {                                      // If there is no event object
    e = window.event;                            // Use old IE event object
  }
  return e.target || e.srcElement;               // Get the target of event
}

	function itemDone(e) {                           // Declare function
  // Remove item from the list
  var target;           						 // Declare variables
  target = getTarget(e);                         // Get the item clicked link
 
  elListItem = target.parentNode;                // Get its li element
  elList = elListItem.parentNode;                // Get the ul element
  elList.removeChild(elListItem);                // Remove list item from list
 
  // Prevent the link from taking you elsewhere
  if (e.preventDefault) {                        // If preventDefault() works
    e.preventDefault();                          // Use preventDefault() 
  } else {                                       // Otherwise
    e.returnValue = false;                       // Use old IE version
  }
}
var el = document.getElementById('test');// Get shopping list
if (el.addEventListener) {                       // If event listeners work
  el.addEventListener('click', function(e) {     // Add listener on click
    itemDone(e);                                 // It calls itemDone()
  }, false);                                     // Use bubbling phase for flow
} else {                                         // Otherwise
  el.attachEvent('onclick', function(e) {        // Use old IE model: onclick
    itemDone(e);                                 // Call itemDone()
  });
}
		
		
	
	

