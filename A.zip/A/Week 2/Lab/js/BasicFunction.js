function Add(){
var num1 =parseInt(document.getElementById("number1").value);
var num2=parseInt(document.getElementById("number2").value);
if (num1 < 10) {
	sum=num1+num2;
	alert("The sum of the two numbers is " + sum);
}
}